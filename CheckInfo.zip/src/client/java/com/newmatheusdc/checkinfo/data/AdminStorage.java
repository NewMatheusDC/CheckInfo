package com.newmatheusdc.checkinfo.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.newmatheusdc.checkinfo.CheckInfoClient;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class AdminStorage {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File STORAGE_FILE = new File(FabricLoader.getInstance().getConfigDir().toFile(), "checkinfo_admins.json");

    private Map<String, Long> registeredAdmins = new HashMap<>();

    public void load() {
        if (STORAGE_FILE.exists()) {
            try (Reader reader = new InputStreamReader(new FileInputStream(STORAGE_FILE), StandardCharsets.UTF_8)) {
                Type type = new TypeToken<Map<String, Long>>() {}.getType();
                registeredAdmins = GSON.fromJson(reader, type);
                if (registeredAdmins == null) {
                    registeredAdmins = new HashMap<>();
                }
            } catch (IOException e) {
                e.printStackTrace();
                registeredAdmins = new HashMap<>();
            }
        }
    }

    public void save() {
        try (Writer writer = new OutputStreamWriter(new FileOutputStream(STORAGE_FILE), StandardCharsets.UTF_8)) {
            GSON.toJson(registeredAdmins, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void checkForNewAdmins(MinecraftClient client) {
        if (!CheckInfoClient.CONFIG.autoDetectAdmins) return;
        if (client.getNetworkHandler() == null) return;

        for (PlayerListEntry entry : client.getNetworkHandler().getPlayerList()) {
            if (entry.getProfile() == null) continue;
            String playerName = entry.getProfile().getName();
            if (playerName == null) continue;

            if (playerName.equalsIgnoreCase(CheckInfoClient.CONFIG.serverOwner)) {
                if (!registeredAdmins.containsKey(playerName)) {
                    registeredAdmins.put(playerName, System.currentTimeMillis());
                    save();
                }
                continue;
            }

            if (entry.getGameMode() != null && entry.getGameMode().getId() == 1) {
                if (!registeredAdmins.containsKey(playerName)) {
                    registeredAdmins.put(playerName, System.currentTimeMillis());
                    save();
                }
            }
        }
    }

    public boolean isAdmin(String playerName) {
        return registeredAdmins.containsKey(playerName) ||
                playerName.equalsIgnoreCase(CheckInfoClient.CONFIG.serverOwner);
    }

    public Map<String, Long> getRegisteredAdmins() {
        return new HashMap<>(registeredAdmins);
    }
}