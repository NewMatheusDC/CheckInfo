package com.newmatheusdc.checkinfo;

import com.newmatheusdc.checkinfo.command.ServerInfoCommand;
import com.newmatheusdc.checkinfo.config.ModConfig;
import com.newmatheusdc.checkinfo.data.AdminStorage;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;

public class CheckInfoClient implements ClientModInitializer {
    public static final String MOD_ID = "checkinfo";
    public static ModConfig CONFIG;
    public static AdminStorage ADMIN_STORAGE;

    @Override
    public void onInitializeClient() {
        CONFIG = ModConfig.load();
        ADMIN_STORAGE = new AdminStorage();
        ADMIN_STORAGE.load();

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            ServerInfoCommand.register(dispatcher);
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player != null && client.getNetworkHandler() != null) {
                ADMIN_STORAGE.checkForNewAdmins(client);
            }
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            ADMIN_STORAGE.save();
        });
    }
}