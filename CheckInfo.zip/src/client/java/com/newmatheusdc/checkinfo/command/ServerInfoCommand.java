package com.newmatheusdc.checkinfo.command;

import com.mojang.brigadier.CommandDispatcher;
import com.newmatheusdc.checkinfo.CheckInfoClient;
import com.newmatheusdc.checkinfo.util.ServerInfoHelper;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.Map;

public class ServerInfoCommand {
    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(ClientCommandManager.literal("svinfo")
                .executes(ctx -> {
                    FabricClientCommandSource src = ctx.getSource();
                    var client = src.getClient();
                    var player = src.getPlayer();

                    if (player == null || client.getNetworkHandler() == null) {
                        src.sendFeedback(Text.translatable("checkinfo.error.not_connected")
                                .formatted(Formatting.RED));
                        return 0;
                    }

                    src.sendFeedback(Text.literal(""));
                    src.sendFeedback(Text.literal("=== CheckInfo - Server Information ===")
                            .formatted(Formatting.GOLD, Formatting.BOLD));

                    if (client.isIntegratedServerRunning()) {
                        src.sendFeedback(Text.translatable("checkinfo.server.type.singleplayer")
                                .formatted(Formatting.AQUA));
                        String worldName = client.getServer().getSaveProperties().getLevelName();
                        src.sendFeedback(Text.translatable("checkinfo.server.world", worldName)
                                .formatted(Formatting.GRAY));
                    } else {
                        src.sendFeedback(Text.translatable("checkinfo.server.type.multiplayer")
                                .formatted(Formatting.AQUA));
                        var serverEntry = client.getCurrentServerEntry();
                        if (serverEntry != null) {
                            String address = serverEntry.address;
                            String name = serverEntry.name;
                            src.sendFeedback(Text.translatable("checkinfo.server.name", name)
                                    .formatted(Formatting.YELLOW));
                            src.sendFeedback(Text.translatable("checkinfo.server.address", address)
                                    .formatted(Formatting.GREEN)
                                    .styled(style -> style
                                            .withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, address))
                                            .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                                                    Text.translatable("checkinfo.click_to_copy")))));
                            String ip = address.contains(":") ? address.substring(0, address.lastIndexOf(':')) : address;
                            int port = address.contains(":") ? Integer.parseInt(address.substring(address.lastIndexOf(':') + 1)) : 25565;
                            src.sendFeedback(Text.translatable("checkinfo.server.ip", ip)
                                    .formatted(Formatting.GREEN));
                            src.sendFeedback(Text.translatable("checkinfo.server.port", port)
                                    .formatted(Formatting.GREEN));
                            if (CheckInfoClient.CONFIG.alternativeIps != null && !CheckInfoClient.CONFIG.alternativeIps.isEmpty()) {
                                src.sendFeedback(Text.translatable("checkinfo.server.alternative_ips")
                                        .formatted(Formatting.LIGHT_PURPLE));
                                for (String altIp : CheckInfoClient.CONFIG.alternativeIps) {
                                    src.sendFeedback(Text.literal("  • " + altIp).formatted(Formatting.GRAY)
                                            .styled(style -> style
                                                    .withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, altIp))
                                                    .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                                                            Text.translatable("checkinfo.click_to_copy")))));
                                }
                            }
                        }
                    }

                    src.sendFeedback(Text.translatable("checkinfo.server.owner")
                            .append(": ")
                            .append(Text.literal(CheckInfoClient.CONFIG.serverOwner)
                                    .formatted(Formatting.GOLD))
                            .formatted(Formatting.WHITE));

                    String motd = ServerInfoHelper.getServerMotd(client);
                    if (motd != null) {
                        src.sendFeedback(Text.translatable("checkinfo.server.motd")
                                .append(": ")
                                .append(Text.literal(motd).formatted(Formatting.GRAY))
                                .formatted(Formatting.WHITE));
                    }

                    String version = ServerInfoHelper.getServerVersion(client);
                    if (version != null) {
                        src.sendFeedback(Text.translatable("checkinfo.server.version")
                                .append(": ")
                                .append(Text.literal(version).formatted(Formatting.GRAY))
                                .formatted(Formatting.WHITE));
                    }

                    int onlinePlayers = ServerInfoHelper.getOnlinePlayerCount(client);
                    int maxPlayers = ServerInfoHelper.getMaxPlayerCount(client);
                    src.sendFeedback(Text.translatable("checkinfo.server.players", onlinePlayers, maxPlayers)
                            .formatted(Formatting.WHITE));

                    List<String> onlinePlayerNames = ServerInfoHelper.getOnlinePlayerNames(client);
                    if (!onlinePlayerNames.isEmpty()) {
                        src.sendFeedback(Text.translatable("checkinfo.server.online_players")
                                .formatted(Formatting.AQUA));
                        for (String playerName : onlinePlayerNames) {
                            boolean isAdmin = CheckInfoClient.ADMIN_STORAGE.isAdmin(playerName);
                            Formatting color = isAdmin ? Formatting.RED : Formatting.GRAY;
                            String adminBadge = isAdmin ? " [ADMIN]" : "";
                            src.sendFeedback(Text.literal("  • " + playerName + adminBadge).formatted(color));
                        }
                    }

                    Map<String, Long> admins = CheckInfoClient.ADMIN_STORAGE.getRegisteredAdmins();
                    if (!admins.isEmpty()) {
                        src.sendFeedback(Text.translatable("checkinfo.server.registered_admins")
                                .formatted(Formatting.DARK_RED));
                        for (Map.Entry<String, Long> entry : admins.entrySet()) {
                            src.sendFeedback(Text.literal("  • " + entry.getKey()).formatted(Formatting.RED));
                        }
                    }

                    src.sendFeedback(Text.literal("=====================================")
                            .formatted(Formatting.GOLD, Formatting.BOLD));
                    src.sendFeedback(Text.literal(""));

                    return 1;
                }));
    }
}