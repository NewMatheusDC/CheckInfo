package com.newmatheusdc.checkinfo.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ServerInfoHelper {
    public static String getServerMotd(MinecraftClient client) {
        if (client.isIntegratedServerRunning() && client.getServer() != null) {
            return client.getServer().getServerMotd();
        } else if (client.getCurrentServerEntry() != null) {
            return client.getCurrentServerEntry().label != null ?
                    client.getCurrentServerEntry().label.getString() :
                    client.getCurrentServerEntry().name;
        }
        return null;
    }

    public static String getServerVersion(MinecraftClient client) {
        if (client.isIntegratedServerRunning() && client.getServer() != null) {
            return client.getServer().getVersion();
        } else if (client.getCurrentServerEntry() != null) {
            return client.getCurrentServerEntry().version != null ?
                    client.getCurrentServerEntry().version.getString() : null;
        }
        return null;
    }

    public static int getOnlinePlayerCount(MinecraftClient client) {
        if (client.getNetworkHandler() != null) {
            Collection<PlayerListEntry> playerList = client.getNetworkHandler().getPlayerList();
            return playerList != null ? playerList.size() : 0;
        }
        return 0;
    }

    public static int getMaxPlayerCount(MinecraftClient client) {
        if (client.isIntegratedServerRunning() && client.getServer() != null) {
            return client.getServer().getMaxPlayerCount();
        }
        return 0;
    }

    public static List<String> getOnlinePlayerNames(MinecraftClient client) {
        List<String> names = new ArrayList<>();
        if (client.getNetworkHandler() != null) {
            Collection<PlayerListEntry> playerList = client.getNetworkHandler().getPlayerList();
            if (playerList != null) {
                for (PlayerListEntry entry : playerList) {
                    if (entry.getProfile() != null && entry.getProfile().getName() != null) {
                        names.add(entry.getProfile().getName());
                    }
                }
            }
        }
        return names;
    }
}